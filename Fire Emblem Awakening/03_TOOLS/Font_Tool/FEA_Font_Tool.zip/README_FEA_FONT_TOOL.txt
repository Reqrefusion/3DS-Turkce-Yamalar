FEA FONT TOOL — HOTFIX 1 UPDATED
================================

Kullanım:
  python fea_font_tool.py extract fonts.zip font_project
  python fea_font_tool.py inject fonts.zip font_project fonts_modified.zip
  python fea_font_tool.py turkish-report fonts.zip

Bu sürüm turkish-report sırasında U+0131 (ı) bitmapinin U+0069 (i) ile birebir
aynı olup olmadığını da kontrol eder. Aynıysa hata olarak raporlar.

Gereksinim: Pillow (pip install pillow)
